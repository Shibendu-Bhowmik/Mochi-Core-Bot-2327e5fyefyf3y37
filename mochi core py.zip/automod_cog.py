"""
automod_cog.py — Auto-moderation for Jarvis Core: spam detection + link filter.

Drop this file next to your other cog files and load it in jarvis_bot.py:
    await bot.load_extension("automod_cog")
"""

import re
import time
import datetime
from collections import defaultdict, deque

import discord
from discord.ext import commands

# ---------- settings you can tweak ----------
SPAM_MESSAGE_LIMIT = 5        # max messages allowed...
SPAM_TIME_WINDOW = 5          # ...within this many seconds
SPAM_TIMEOUT_MINUTES = 1      # timeout duration when spam is detected

BLOCK_ALL_LINKS = False               # if True, deletes ANY link from non-exempt members
BLOCK_DISCORD_INVITES = True          # blocks discord.gg/... invite links specifically
EXEMPT_ROLE_NAMES = {"Mod", "Admin"}  # role names that bypass auto-mod entirely

URL_PATTERN = re.compile(r"https?://\S+")
INVITE_PATTERN = re.compile(r"(discord\.gg|discordapp\.com/invite|discord\.com/invite)/\S+", re.IGNORECASE)


class AutoModCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # user_id -> deque of recent message timestamps
        self.message_times = defaultdict(lambda: deque(maxlen=SPAM_MESSAGE_LIMIT))

    def _is_exempt(self, member: discord.Member) -> bool:
        if member.guild_permissions.administrator:
            return True
        return any(role.name in EXEMPT_ROLE_NAMES for role in member.roles)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        if self._is_exempt(message.author):
            return

        # ---- spam check ----
        times = self.message_times[message.author.id]
        times.append(time.time())
        if len(times) == SPAM_MESSAGE_LIMIT and (times[-1] - times[0]) < SPAM_TIME_WINDOW:
            try:
                await message.author.timeout(
                    discord.utils.utcnow() + datetime.timedelta(minutes=SPAM_TIMEOUT_MINUTES),
                    reason="Auto-mod: message spam",
                )
                await message.channel.send(
                    f"⏱️ {message.author.mention} timed out for {SPAM_TIMEOUT_MINUTES}m — sending messages too fast."
                )
            except discord.Forbidden:
                pass
            times.clear()
            return  # don't also run the link check on a message already flagged as spam

        # ---- link check ----
        content = message.content
        if BLOCK_DISCORD_INVITES and INVITE_PATTERN.search(content):
            await self._delete_and_warn(message, "posting a Discord invite link")
            return
        if BLOCK_ALL_LINKS and URL_PATTERN.search(content):
            await self._delete_and_warn(message, "posting a link")
            return

    async def _delete_and_warn(self, message: discord.Message, reason: str):
        try:
            await message.delete()
        except discord.Forbidden:
            return
        warning = await message.channel.send(
            f"🚫 {message.author.mention}, that got removed — {reason} isn't allowed here."
        )
        await warning.delete(delay=6)


async def setup(bot: commands.Bot):
    await bot.add_cog(AutoModCog(bot))
