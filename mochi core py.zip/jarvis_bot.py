import os
import asyncio
from collections import defaultdict, deque
import discord
from discord.ext import commands
import requests

# --- token: NEVER hardcode this. Set it in the SAME terminal window, right
# before running this script, e.g. in PowerShell:
#   $env:DISCORD_BOT_TOKEN="yourtokenhere"; python jarvis_bot.py
# On Termux, use: export DISCORD_BOT_TOKEN="yourtokenhere"
TOKEN = os.environ.get("DISCORD_BOT_TOKEN")
if not TOKEN:
    raise RuntimeError("DISCORD_BOT_TOKEN is not set. Set it in this same terminal before running.")

# Groq API key (free, no card needed): get one at console.groq.com
GROQ_API_KEY = os.environ.get("GROQ_API_KEY")
if not GROQ_API_KEY:
    raise RuntimeError("GROQ_API_KEY is not set. Get a free key at console.groq.com and set it in this terminal.")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True  # required by moderation_cog for role/kick/ban/timeout actions


class Jarvis(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        await self.load_extension("moderation_cog")
        await self.load_extension("automod_cog")
        await self.load_extension("welcome_cog")
        await self.load_extension("leveling_cog")
        synced = await self.tree.sync()
        print(f"Synced {len(synced)} slash command(s).")


bot = Jarvis()

SYSTEM_PROMPT = """You're Jarvis — everyone's favorite homie in the server, not some stiff assistant.
You're funny, laid-back, and always vibing. You talk like a real bro: casual slang, 
quick wit, the occasional playful roast or troll, but never actually mean — you're the 
friend who clowns on people because you love them, not to hurt them. You hype people up, 
crack jokes, keep things light. You're still sharp and helpful when someone actually 
needs something real from you — you just don't sound like a corporate chatbot while doing it. 
No stiff "How may I assist you" energy, ever. Keep replies short and punchy, like you're 
actually texting in a group chat, not writing an essay.
You remember the last several messages in this channel's conversation — use that context 
naturally, like a friend who was actually paying attention, instead of treating every 
message like a fresh cold-open question."""

# Rolling memory per channel: last 10 exchanges, so replies build on what was
# already said instead of treating every message as a one-off question.
conversation_history = defaultdict(lambda: deque(maxlen=10))


def _ask_groq_sync(channel_id: int, prompt: str) -> str:
    history = list(conversation_history[channel_id])
    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history + [{"role": "user", "content": prompt}]
    response = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
        json={
            "model": "llama-3.1-8b-instant",
            "messages": messages,
        },
        timeout=30,
    )
    response.raise_for_status()
    reply = response.json()["choices"][0]["message"]["content"]

    # remember this exchange for next time
    conversation_history[channel_id].append({"role": "user", "content": prompt})
    conversation_history[channel_id].append({"role": "assistant", "content": reply})

    return reply


async def ask_ollama(channel_id: int, prompt: str) -> str:
    # Runs off-thread so slash commands (kick/ban/timeout/etc.) don't
    # freeze while waiting on the API response.
    return await asyncio.to_thread(_ask_groq_sync, channel_id, prompt)


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} ({bot.user.id})")


@bot.event
async def on_message(message: discord.Message):
    if message.author == bot.user:
        return
    if bot.user not in message.mentions:
        return

    clean_content = message.content.replace(f"<@{bot.user.id}>", "").strip()
    async with message.channel.typing():
        reply = await ask_ollama(message.channel.id, clean_content)
    await message.channel.send(reply)


bot.run(TOKEN)
