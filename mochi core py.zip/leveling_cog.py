"""
leveling_cog.py — XP/leveling system for Jarvis Core (like MEE6).

Drop this file next to your other cog files and load it in jarvis_bot.py:
    await bot.load_extension("leveling_cog")

Commands:
    /rank [member]   — show XP and level
    /leaderboard     — show top 10 members by XP in this server
"""

import json
import os
import time

import discord
from discord import app_commands
from discord.ext import commands

XP_FILE = "levels.json"
XP_PER_MESSAGE = 15
XP_COOLDOWN_SECONDS = 60   # only earns XP once per this many seconds, per user
LEVEL_UP_ANNOUNCE = True  # post a message in-channel when someone levels up


def _load_xp() -> dict:
    if not os.path.exists(XP_FILE):
        return {}
    with open(XP_FILE, "r") as f:
        return json.load(f)


def _save_xp(data: dict) -> None:
    with open(XP_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _level_for_xp(xp: int) -> int:
    # Each level needs progressively more XP than the last.
    level = 0
    needed = 100
    while xp >= needed:
        xp -= needed
        level += 1
        needed = int(needed * 1.2)
    return level


class LevelingCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.cooldowns = {}  # (guild_id, user_id) -> last XP-earning timestamp

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        key = (message.guild.id, message.author.id)
        now = time.time()
        if now - self.cooldowns.get(key, 0) < XP_COOLDOWN_SECONDS:
            return
        self.cooldowns[key] = now

        data = _load_xp()
        gid, uid = str(message.guild.id), str(message.author.id)
        data.setdefault(gid, {})
        old_xp = data[gid].get(uid, 0)
        new_xp = old_xp + XP_PER_MESSAGE
        data[gid][uid] = new_xp
        _save_xp(data)

        if LEVEL_UP_ANNOUNCE and _level_for_xp(new_xp) > _level_for_xp(old_xp):
            await message.channel.send(
                f"🎉 {message.author.mention} leveled up to **level {_level_for_xp(new_xp)}**!"
            )

    @app_commands.command(name="rank", description="Check your (or someone else's) level and XP")
    async def rank(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        data = _load_xp()
        xp = data.get(str(interaction.guild.id), {}).get(str(member.id), 0)
        level = _level_for_xp(xp)
        await interaction.response.send_message(f"📊 {member.mention} — Level **{level}**, {xp} total XP")

    @app_commands.command(name="leaderboard", description="Show the top 10 members by XP")
    async def leaderboard(self, interaction: discord.Interaction):
        data = _load_xp().get(str(interaction.guild.id), {})
        if not data:
            return await interaction.response.send_message("No XP recorded yet.")
        top = sorted(data.items(), key=lambda kv: kv[1], reverse=True)[:10]
        lines = []
        for i, (uid, xp) in enumerate(top, start=1):
            member = interaction.guild.get_member(int(uid))
            name = member.display_name if member else f"User {uid}"
            lines.append(f"{i}. {name} — Level {_level_for_xp(xp)} ({xp} XP)")
        await interaction.response.send_message("**🏆 Leaderboard**\n" + "\n".join(lines))


async def setup(bot: commands.Bot):
    await bot.add_cog(LevelingCog(bot))
