"""
moderation_cog.py — Moderator/Manager powers for Jarvis Core

Drop this file next to your main bot file and load it with:
    await bot.load_extension("moderation_cog")

Requires (in your main bot file):
    intents = discord.Intents.default()
    intents.members = True   # required for role/member management

Bot needs these SERVER PERMISSIONS to actually act:
    Manage Roles, Kick Members, Ban Members, Moderate Members (timeout),
    Manage Messages (purge)

IMPORTANT: In Discord, a bot can only manage roles that sit BELOW its own
highest role in the server's role list. Make sure Jarvis's bot role is
positioned above any role you want it to assign/remove.
"""

import discord
from discord import app_commands
from discord.ext import commands
import json
import os
from datetime import timedelta, datetime, timezone

WARN_FILE = "warnings.json"
MOD_LOG_CHANNEL_ID = None  # set to an int channel ID to enable mod-log embeds, or leave None


def _load_warns() -> dict:
    if not os.path.exists(WARN_FILE):
        return {}
    with open(WARN_FILE, "r") as f:
        return json.load(f)


def _save_warns(data: dict) -> None:
    with open(WARN_FILE, "w") as f:
        json.dump(data, f, indent=2)


class ModerationCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ---------- shared helpers ----------

    async def _log(self, guild: discord.Guild, embed: discord.Embed):
        if MOD_LOG_CHANNEL_ID is None:
            return
        channel = guild.get_channel(MOD_LOG_CHANNEL_ID)
        if channel:
            await channel.send(embed=embed)

    def _hierarchy_ok(self, actor: discord.Member, target: discord.Member) -> bool:
        """Prevents acting on someone with an equal/higher role than the actor."""
        return actor.top_role > target.top_role or actor.id == actor.guild.owner_id

    # ---------- role management ----------

    @app_commands.command(name="promote", description="Assign a role to a member")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def promote(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        if not self._hierarchy_ok(interaction.user, member):
            return await interaction.response.send_message(
                "You can't act on someone with an equal or higher role than you.", ephemeral=True
            )
        if role >= interaction.guild.me.top_role:
            return await interaction.response.send_message(
                "I can't assign a role that's above or equal to my own highest role.", ephemeral=True
            )
        await member.add_roles(role, reason=f"Promoted by {interaction.user}")
        await interaction.response.send_message(f"✅ Gave **{role.name}** to {member.mention}")
        await self._log(interaction.guild, discord.Embed(
            title="Role Added", description=f"{member.mention} → **{role.name}**\nBy {interaction.user.mention}",
            color=discord.Color.green(), timestamp=datetime.now(timezone.utc)
        ))

    @app_commands.command(name="demote", description="Remove a role from a member")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def demote(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        if not self._hierarchy_ok(interaction.user, member):
            return await interaction.response.send_message(
                "You can't act on someone with an equal or higher role than you.", ephemeral=True
            )
        await member.remove_roles(role, reason=f"Demoted by {interaction.user}")
        await interaction.response.send_message(f"✅ Removed **{role.name}** from {member.mention}")
        await self._log(interaction.guild, discord.Embed(
            title="Role Removed", description=f"{member.mention} lost **{role.name}**\nBy {interaction.user.mention}",
            color=discord.Color.orange(), timestamp=datetime.now(timezone.utc)
        ))

    # ---------- kick / ban ----------

    @app_commands.command(name="kick", description="Kick a member")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason given"):
        if not self._hierarchy_ok(interaction.user, member):
            return await interaction.response.send_message(
                "You can't act on someone with an equal or higher role than you.", ephemeral=True
            )
        await member.kick(reason=reason)
        await interaction.response.send_message(f"👢 Kicked {member} — {reason}")
        await self._log(interaction.guild, discord.Embed(
            title="Member Kicked", description=f"{member} — {reason}\nBy {interaction.user.mention}",
            color=discord.Color.red(), timestamp=datetime.now(timezone.utc)
        ))

    @app_commands.command(name="ban", description="Ban a member")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason given"):
        if not self._hierarchy_ok(interaction.user, member):
            return await interaction.response.send_message(
                "You can't act on someone with an equal or higher role than you.", ephemeral=True
            )
        await member.ban(reason=reason)
        await interaction.response.send_message(f"🔨 Banned {member} — {reason}")
        await self._log(interaction.guild, discord.Embed(
            title="Member Banned", description=f"{member} — {reason}\nBy {interaction.user.mention}",
            color=discord.Color.dark_red(), timestamp=datetime.now(timezone.utc)
        ))

    @app_commands.command(name="unban", description="Unban a user by their user ID")
    @app_commands.checks.has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str):
        user = discord.Object(id=int(user_id))
        await interaction.guild.unban(user, reason=f"Unbanned by {interaction.user}")
        await interaction.response.send_message(f"✅ Unbanned user ID {user_id}")

    # ---------- timeout (mute) ----------

    @app_commands.command(name="timeout", description="Timeout a member for N minutes")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def timeout(self, interaction: discord.Interaction, member: discord.Member,
                       minutes: int, reason: str = "No reason given"):
        if not self._hierarchy_ok(interaction.user, member):
            return await interaction.response.send_message(
                "You can't act on someone with an equal or higher role than you.", ephemeral=True
            )
        await member.timeout(timedelta(minutes=minutes), reason=reason)
        await interaction.response.send_message(f"🔇 Timed out {member} for {minutes}m — {reason}")
        await self._log(interaction.guild, discord.Embed(
            title="Member Timed Out", description=f"{member} — {minutes}m — {reason}\nBy {interaction.user.mention}",
            color=discord.Color.gold(), timestamp=datetime.now(timezone.utc)
        ))

    @app_commands.command(name="untimeout", description="Remove a member's timeout")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def untimeout(self, interaction: discord.Interaction, member: discord.Member):
        await member.timeout(None, reason=f"Timeout removed by {interaction.user}")
        await interaction.response.send_message(f"🔊 Timeout removed for {member}")

    # ---------- warns ----------

    @app_commands.command(name="warn", description="Warn a member (tracked persistently)")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason given"):
        data = _load_warns()
        gid, mid = str(interaction.guild.id), str(member.id)
        data.setdefault(gid, {}).setdefault(mid, [])
        data[gid][mid].append({
            "reason": reason,
            "by": str(interaction.user),
            "at": datetime.now(timezone.utc).isoformat(),
        })
        _save_warns(data)
        count = len(data[gid][mid])
        await interaction.response.send_message(f"⚠️ Warned {member} (total: {count}) — {reason}")
        await self._log(interaction.guild, discord.Embed(
            title="Member Warned", description=f"{member} — {reason}\nTotal warns: {count}\nBy {interaction.user.mention}",
            color=discord.Color.yellow(), timestamp=datetime.now(timezone.utc)
        ))

    @app_commands.command(name="warnings", description="List a member's warnings")
    async def warnings(self, interaction: discord.Interaction, member: discord.Member):
        data = _load_warns()
        entries = data.get(str(interaction.guild.id), {}).get(str(member.id), [])
        if not entries:
            return await interaction.response.send_message(f"{member} has no warnings.")
        lines = [f"{i+1}. {e['reason']} — by {e['by']} ({e['at'][:10]})" for i, e in enumerate(entries)]
        await interaction.response.send_message(f"**Warnings for {member}:**\n" + "\n".join(lines))

    @app_commands.command(name="clearwarnings", description="Clear a member's warnings")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def clearwarnings(self, interaction: discord.Interaction, member: discord.Member):
        data = _load_warns()
        gid, mid = str(interaction.guild.id), str(member.id)
        if gid in data and mid in data[gid]:
            del data[gid][mid]
            _save_warns(data)
        await interaction.response.send_message(f"✅ Cleared warnings for {member}")

    # ---------- purge ----------

    @app_commands.command(name="purge", description="Bulk delete recent messages in this channel")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def purge(self, interaction: discord.Interaction, amount: int):
        if amount < 1 or amount > 100:
            return await interaction.response.send_message("Pick a number between 1 and 100.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"🧹 Deleted {len(deleted)} messages.", ephemeral=True)

    # ---------- error handling for all app_commands in this cog ----------

    async def cog_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have permission to do that.", ephemeral=True)
        else:
            await interaction.response.send_message(f"Something went wrong: {error}", ephemeral=True)
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(ModerationCog(bot))
