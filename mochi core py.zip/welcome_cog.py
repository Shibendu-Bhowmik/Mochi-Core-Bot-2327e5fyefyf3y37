"""
welcome_cog.py — Welcome / leave messages for Jarvis Core.

Drop this file next to your other cog files and load it in jarvis_bot.py:
    await bot.load_extension("welcome_cog")

IMPORTANT: set WELCOME_CHANNEL_ID below to the channel where these should post.
To get a channel ID: User Settings → Advanced → turn on Developer Mode,
then right-click the channel in Discord → Copy Channel ID, paste the number below.
"""

import discord
from discord.ext import commands

WELCOME_CHANNEL_ID = 1552511135545294859  # <-- replace 0 with your real channel ID


class WelcomeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        channel = member.guild.get_channel(WELCOME_CHANNEL_ID)
        if not channel:
            return
        embed = discord.Embed(
            title="Welcome!",
            description=f"{member.mention} just joined **{member.guild.name}** — glad you're here 👋",
            color=discord.Color.green(),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Member #{member.guild.member_count}")
        await channel.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        channel = member.guild.get_channel(WELCOME_CHANNEL_ID)
        if not channel:
            return
        embed = discord.Embed(
            description=f"**{member}** left the server.",
            color=discord.Color.red(),
        )
        await channel.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(WelcomeCog(bot))
